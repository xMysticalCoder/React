import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Dont Click", "./Sprite1/costumes/Dont Click.svg", {
        x: 291.2597198028105,
        y: 203.617244869381
      }),
      new Costume("Thumbnail", "./Sprite1/costumes/Thumbnail.svg", {
        x: 291.2597198028105,
        y: 203.61725486938101
      }),
      new Costume("Note", "./Sprite1/costumes/Note.svg", {
        x: 291.2597198028105,
        y: 203.61725486938104
      }),
      new Costume("Fail", "./Sprite1/costumes/Fail.svg", {
        x: 291.2597198028105,
        y: 203.61725486938104
      }),
      new Costume("Click", "./Sprite1/costumes/Click.svg", {
        x: 291.2597198028105,
        y: 203.61725486938101
      }),
      new Costume("Pass", "./Sprite1/costumes/Pass.svg", {
        x: 291.2597198028105,
        y: 203.61725486938104
      })
    ];

    this.sounds = [new Sound("Meow", "./Sprite1/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.ms.visible = false;
    this.stage.watchers.GlobalMs.visible = false;
    this.stage.vars.ms = 0;
    this.costume = "Note";
    yield* this.wait(2);
    this.costume = "Dont Click";
    yield* this.showIn(this.random(1, 6));
  }

  *whenthisspriteclicked() {
    if (this.costume.name == "Click") {
      this.costume = "Pass";
    } else {
      if (this.costume.name == "Dont Click") {
        this.costume = "Fail";
        /* TODO: Implement stop all */ null;
      }
    }
  }

  *showIn(seconds) {
    this.stage.vars.ms = 0;
    yield* this.wait(seconds);
    this.costume = "Click";
    this.restartTimer();
    while (!(this.costume.name == "Pass")) {
      yield;
    }
    this.stage.vars.ms = this.timer * 1000;
    if (this.stage.vars.ms < this.stage.vars.GlobalMs) {
      this.stage.vars.GlobalMs = this.stage.vars.ms;
    }
    this.stage.watchers.ms.visible = true;
    this.stage.watchers.GlobalMs.visible = true;
  }
}
