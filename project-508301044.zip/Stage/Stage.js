import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.ms = 0;
    this.vars.GlobalMs = 396;

    this.watchers.ms = new Watcher({
      label: "ms",
      style: "large",
      visible: false,
      value: () => this.vars.ms,
      x: 539.4600830078125,
      y: 103.03627014160156
    });
    this.watchers.GlobalMs = new Watcher({
      label: "☁ global ms",
      style: "large",
      visible: false,
      value: () => this.vars.GlobalMs,
      x: 582.1354370117188,
      y: 7.0846405029296875
    });
  }
}
